from django.contrib import admin
from .models import Demo
from .models import contactless

admin.site.register(Demo)
admin.site.register(contactless)
# Register your models here.
