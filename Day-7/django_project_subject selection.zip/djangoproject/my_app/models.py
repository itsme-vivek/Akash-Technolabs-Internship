from django.db import models
from datetime import datetime, date

class Demo(models.Model):
    FirstName = models.CharField(max_length=100)
    LastName = models.CharField(max_length=100)
    Enrollment = models.CharField(max_length=100)
    Email = models.CharField(max_length=100)
    Number = models.CharField(max_length=10)
    date = models.DateField(auto_now_add=False, auto_now=False, blank=True)
    CollegeName = models.CharField(max_length=100)
    Branch = models.CharField(max_length=100)
    Semester = models.CharField(max_length=2)
    Subject = models.CharField(max_length=100)
    
class contactless(models.Model):
    # is_private = models.BooleanField(default=False)
    Name = models.CharField(max_length=30)
    mobile = models.CharField(max_length=10)    

# Create your models here.
