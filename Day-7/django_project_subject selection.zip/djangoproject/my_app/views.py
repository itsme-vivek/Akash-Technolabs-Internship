from django.shortcuts import render,redirect
from django.contrib.auth.models import User , auth 
from django.views import generic
from .models import Demo
from .models import contactless

def homepageview(request):
    return render(request,'home.html')


def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):
    return render(request,'contact.html')

def contactprocess(request):
    
    print("Query Added")
    if request.method == "POST":
        a = request.POST.get('name')
        b = request.POST.get('mobile')
        user = contactless(Name=a, mobile=b)
        user.save()
        return redirect('/')
    else:
        return render(request,'form.html')   

def formprocess(request):
    print("done")
    if request.method == "POST":
        a = request.POST['fname']
        b = request.POST['lname']
        c = request.POST['er']
        d = request.POST['email']
        e = request.POST['number']
        f = request.POST['clgname']
        g = request.POST['branch']
        h = request.POST['semester']
        i = request.POST['sub']
        j = request.POST['date']
        user = Demo( FirstName=a , LastName=b, Enrollment=c,  Email=d ,  Number=e , CollegeName=f,  Branch=g,  Semester=h,  Subject=i, date=j )
        user.save()
        print("Its Done")
        return redirect('/')

    else:
        return render(request,'form.html')    

def form(request):
   return render(request,'form.html')